step 1. 
    bash setup.sh

step 2:
  put the file into corresponding folder

